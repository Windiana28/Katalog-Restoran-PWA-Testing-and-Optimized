const assert = require('assert');

Feature('Liking Restaurants');

Before(({ I }) => {
  I.amOnPage('/#/favorites');
});

const restaurantKosong = 'Tidak ada resto untuk ditampilkan';
Scenario('showing empty liked restos', ({ I }) => {
  I.seeElement('.list');
  I.see(restaurantKosong, '.restaurants');
});

Scenario('liking one restaurant', async ({ I }) => {
  I.see('Tidak ada restaurant untuk ditampilkan', '.restaurants');

  I.amOnPage('/');

  I.seeElement('.restaurant__title a');

  const firstResto = locate('.restaurant__title a').first();
  const firstRestoTitle = await I.grabTextFrom(firstResto);
  I.click(firstResto);

  I.seeElement('#likeButton');
  I.click('#likeButton');

  I.amOnPage('/#/favorites');
  I.seeElement('.Restaurants');
  const likedRestoTitle = await I.grabTextFrom('.restaurant__title');

  assert.strictEqual(firstRestoTitle, likedRestoTitle);
});

Scenario('unfavorite restaurant', ({ I }) => {
  I.see('your favorite restaurant', '.content__heading');

  I.amOnPage('/');
  I.seeElement('.post-item__title a');

  const firstRestaurant = locate('.content__heading').first();
  I.click(firstRestaurant);

  I.seeElement('#likeButton');
  I.click('#likeButton');

  I.amOnPage('/#/favorites');
  I.seeElement('.restaurants');

  I.click(firstRestaurant);

  I.seeElement('#likeButton');
  I.click('#likeButton');

  I.amOnPage('/#/favorites');
  I.see('Lets add your favorite restaurant', '.content__heading');
});
